from __future__ import unicode_literals

from django.apps import AppConfig


class ConfigureAndRunAnalysis(AppConfig):
    name = 'configure_and_run_analysis'
