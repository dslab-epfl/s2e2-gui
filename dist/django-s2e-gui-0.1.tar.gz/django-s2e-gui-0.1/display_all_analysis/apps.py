from __future__ import unicode_literals

from django.apps import AppConfig


class DisplayAllAnalysis(AppConfig):
    name = 'display_all_analysis'
