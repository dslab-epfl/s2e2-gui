from django.http import HttpResponse
from django.shortcuts import render
from models import Analysis
import s2e_web.S2E_settings as settings
import shutil
import os
from configure_and_run_analysis.views import displayAnalysisInDir
from cups import HTTP_OK


def handleRequest(request):
	"""
	Handle the requests from the display_all_analysis page.
	"""
		
	if (request.method == 'GET'):
		return render(request, 'display_all_analysis/index.html', {"analysis" : Analysis.objects.all()})
	
	elif (request.method == 'POST'):
		if(request.POST["method"] == "display"):
			s2e_num = request.POST["s2e_num"]
			binary_name = request.POST["binary_name"]
			return displayAnalysisInDir(request, s2e_num, binary_name)
		elif(request.POST["method"] == "remove"):
			s2e_num = request.POST["s2e_num"]
			binary_name = request.POST["binary_name"]
			
			Analysis.objects.filter(binary_name=binary_name, s2e_num=s2e_num).delete()
			
			s2e_output_dir_to_delete = os.path.join(settings.S2E_PROJECT_FOLDER_PATH, binary_name) + "/s2e-out-" + s2e_num + "/"
			shutil.rmtree(s2e_output_dir_to_delete)
			
			return HttpResponse(status=200)
		

